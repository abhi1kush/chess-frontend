// src/redux/reducers/gameReducer.js
import { Chess } from 'chess.js';
import {
  MOVE_PIECE,
  RESET_GAME,
  LOAD_GAME,
  SET_GAME_OVER,
  SET_TIMER_DURATION,
} from '../actions/gameActions';
import CONFIG from '../../config';

interface LastMove {
  from: string;
  to: string;
}

interface GameState {
  fen: string;
  isWhiteTurn: boolean;
  moveHistory: string[];
  lastMove: LastMove | null;
  isGameOver: boolean;
  gameResult: string;
  timerDuration: number;
}

interface MovePieceAction {
  type: typeof MOVE_PIECE;
  payload: {
    from: string;
    to: string;
    promotionPiece?: string;
  };
}

interface ResetGameAction {
  type: typeof RESET_GAME;
  payload: number;
}

interface LoadGameAction {
  type: typeof LOAD_GAME;
  payload: {
    fen: string;
    moveHistory?: string[];
  };
}

interface SetGameOverAction {
  type: typeof SET_GAME_OVER;
  payload: {
    isGameOver: boolean;
    gameResult: string;
  };
}

interface SetTimerDurationAction {
  type: typeof SET_TIMER_DURATION;
  payload: number;
}

type GameAction =
  | MovePieceAction
  | ResetGameAction
  | LoadGameAction
  | SetGameOverAction
  | SetTimerDurationAction;

const initialState: GameState = {
  fen: CONFIG.START_FEN,
  isWhiteTurn: true,
  moveHistory: [],
  lastMove: null,
  isGameOver: false,
  gameResult: '',
  timerDuration: CONFIG.TIMER_DURATION,
};

const gameReducer = (
  state: GameState = initialState,
  action: GameAction,
): GameState => {
  switch (action.type) {
    case MOVE_PIECE:
      try {
        const game = new Chess(state.fen);

        const move = game.move({
          from: action.payload.from,
          to: action.payload.to,
          promotion: action.payload.promotionPiece,
        });

        if (!move) {
          return state;
        }

        const newHistory = [
          ...state.moveHistory,
          move.san,
        ];

        return {
          ...state,
          fen: game.fen(),
          isWhiteTurn: !state.isWhiteTurn,
          moveHistory: newHistory,
          lastMove: {
            from: action.payload.from,
            to: action.payload.to,
          },
        };
      } catch {
        return state;
      }

    case RESET_GAME:
      return {
        ...initialState,
        moveHistory: [],
        timerDuration: action.payload,
      };

    case LOAD_GAME:
      return {
        ...state,
        fen: action.payload.fen,
        moveHistory: action.payload.moveHistory || [],
      };

    case SET_GAME_OVER:
      return {
        ...state,
        isGameOver: action.payload.isGameOver,
        gameResult: action.payload.gameResult,
      };

    case SET_TIMER_DURATION:
      return {
        ...state,
        timerDuration: action.payload,
      };

    default:
      return state;
  }
};

export default gameReducer;